package com.onlinedairy.service;

import com.onlinedairy.model.AppUser;
import com.onlinedairy.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private AppUserRepository userRepository;

    public AppUser addFarmer(AppUser user) {
        user.setRole("ROLE_FARMER");
        return userRepository.save(user);
    }

    public AppUser addEmployee(AppUser user) {
        user.setRole("ROLE_EMPLOYEE");
        return userRepository.save(user);
    }

    public AppUser addManager(AppUser user) {
        user.setRole("ROLE_MANAGER");
        return userRepository.save(user);
    }
    public ResponseEntity<?> validateUser(String email, String password) {
        Optional<AppUser> user = userRepository.findByEmailAndPassword(email, password);

        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid email or password");
        }
    }
}